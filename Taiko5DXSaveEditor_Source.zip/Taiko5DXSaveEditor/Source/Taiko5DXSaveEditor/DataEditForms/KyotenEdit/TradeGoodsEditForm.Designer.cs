﻿
namespace Taiko5DXSaveEditor.DataEditForms.KyotenEdit
{
    partial class TradeGoodsEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._CancelButton = new System.Windows.Forms.Button();
            this._OKButton = new System.Windows.Forms.Button();
            this._TradeGoods1ComboBox = new System.Windows.Forms.ComboBox();
            this._TradeGoods2ComboBox = new System.Windows.Forms.ComboBox();
            this._TradeGoods3ComboBox = new System.Windows.Forms.ComboBox();
            this._TradeGoods4ComboBox = new System.Windows.Forms.ComboBox();
            this._TradeGoods5ComboBox = new System.Windows.Forms.ComboBox();
            this._TradeGoods6ComboBox = new System.Windows.Forms.ComboBox();
            this._TradeGoods7ComboBox = new System.Windows.Forms.ComboBox();
            this._TradeGoods8ComboBox = new System.Windows.Forms.ComboBox();
            this._TradeGoods9ComboBox = new System.Windows.Forms.ComboBox();
            this._TradeGoods10ComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this._TradeGoodsSupplyRate1TextBox = new System.Windows.Forms.TextBox();
            this._TradeGoodsSupplyRate2TextBox = new System.Windows.Forms.TextBox();
            this._TradeGoodsSupplyRate3TextBox = new System.Windows.Forms.TextBox();
            this._TradeGoodsSupplyRate4TextBox = new System.Windows.Forms.TextBox();
            this._TradeGoodsSupplyRate5TextBox = new System.Windows.Forms.TextBox();
            this._TradeGoodsSupplyRate6TextBox = new System.Windows.Forms.TextBox();
            this._TradeGoodsSupplyRate7TextBox = new System.Windows.Forms.TextBox();
            this._TradeGoodsSupplyRate8TextBox = new System.Windows.Forms.TextBox();
            this._TradeGoodsSupplyRate9TextBox = new System.Windows.Forms.TextBox();
            this._TradeGoodsSupplyRate10TextBox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this._ToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // _CancelButton
            // 
            this._CancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this._CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._CancelButton.Location = new System.Drawing.Point(337, 366);
            this._CancelButton.Name = "_CancelButton";
            this._CancelButton.Size = new System.Drawing.Size(75, 23);
            this._CancelButton.TabIndex = 101;
            this._CancelButton.Text = "キャンセル";
            this._CancelButton.UseVisualStyleBackColor = true;
            this._CancelButton.Click += new System.EventHandler(this._CancelButton_Click);
            // 
            // _OKButton
            // 
            this._OKButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this._OKButton.Location = new System.Drawing.Point(251, 366);
            this._OKButton.Name = "_OKButton";
            this._OKButton.Size = new System.Drawing.Size(75, 23);
            this._OKButton.TabIndex = 100;
            this._OKButton.Text = "OK";
            this._OKButton.UseVisualStyleBackColor = true;
            this._OKButton.Click += new System.EventHandler(this._OKButton_Click);
            // 
            // _TradeGoods1ComboBox
            // 
            this._TradeGoods1ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._TradeGoods1ComboBox.FormattingEnabled = true;
            this._TradeGoods1ComboBox.Location = new System.Drawing.Point(73, 12);
            this._TradeGoods1ComboBox.Name = "_TradeGoods1ComboBox";
            this._TradeGoods1ComboBox.Size = new System.Drawing.Size(160, 23);
            this._TradeGoods1ComboBox.TabIndex = 0;
            // 
            // _TradeGoods2ComboBox
            // 
            this._TradeGoods2ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._TradeGoods2ComboBox.FormattingEnabled = true;
            this._TradeGoods2ComboBox.Location = new System.Drawing.Point(73, 46);
            this._TradeGoods2ComboBox.Name = "_TradeGoods2ComboBox";
            this._TradeGoods2ComboBox.Size = new System.Drawing.Size(160, 23);
            this._TradeGoods2ComboBox.TabIndex = 2;
            // 
            // _TradeGoods3ComboBox
            // 
            this._TradeGoods3ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._TradeGoods3ComboBox.FormattingEnabled = true;
            this._TradeGoods3ComboBox.Location = new System.Drawing.Point(73, 80);
            this._TradeGoods3ComboBox.Name = "_TradeGoods3ComboBox";
            this._TradeGoods3ComboBox.Size = new System.Drawing.Size(160, 23);
            this._TradeGoods3ComboBox.TabIndex = 4;
            // 
            // _TradeGoods4ComboBox
            // 
            this._TradeGoods4ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._TradeGoods4ComboBox.FormattingEnabled = true;
            this._TradeGoods4ComboBox.Location = new System.Drawing.Point(73, 114);
            this._TradeGoods4ComboBox.Name = "_TradeGoods4ComboBox";
            this._TradeGoods4ComboBox.Size = new System.Drawing.Size(160, 23);
            this._TradeGoods4ComboBox.TabIndex = 6;
            // 
            // _TradeGoods5ComboBox
            // 
            this._TradeGoods5ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._TradeGoods5ComboBox.FormattingEnabled = true;
            this._TradeGoods5ComboBox.Location = new System.Drawing.Point(73, 148);
            this._TradeGoods5ComboBox.Name = "_TradeGoods5ComboBox";
            this._TradeGoods5ComboBox.Size = new System.Drawing.Size(160, 23);
            this._TradeGoods5ComboBox.TabIndex = 8;
            // 
            // _TradeGoods6ComboBox
            // 
            this._TradeGoods6ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._TradeGoods6ComboBox.FormattingEnabled = true;
            this._TradeGoods6ComboBox.Location = new System.Drawing.Point(73, 182);
            this._TradeGoods6ComboBox.Name = "_TradeGoods6ComboBox";
            this._TradeGoods6ComboBox.Size = new System.Drawing.Size(160, 23);
            this._TradeGoods6ComboBox.TabIndex = 10;
            // 
            // _TradeGoods7ComboBox
            // 
            this._TradeGoods7ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._TradeGoods7ComboBox.FormattingEnabled = true;
            this._TradeGoods7ComboBox.Location = new System.Drawing.Point(73, 216);
            this._TradeGoods7ComboBox.Name = "_TradeGoods7ComboBox";
            this._TradeGoods7ComboBox.Size = new System.Drawing.Size(160, 23);
            this._TradeGoods7ComboBox.TabIndex = 12;
            // 
            // _TradeGoods8ComboBox
            // 
            this._TradeGoods8ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._TradeGoods8ComboBox.FormattingEnabled = true;
            this._TradeGoods8ComboBox.Location = new System.Drawing.Point(73, 250);
            this._TradeGoods8ComboBox.Name = "_TradeGoods8ComboBox";
            this._TradeGoods8ComboBox.Size = new System.Drawing.Size(160, 23);
            this._TradeGoods8ComboBox.TabIndex = 14;
            // 
            // _TradeGoods9ComboBox
            // 
            this._TradeGoods9ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._TradeGoods9ComboBox.FormattingEnabled = true;
            this._TradeGoods9ComboBox.Location = new System.Drawing.Point(73, 284);
            this._TradeGoods9ComboBox.Name = "_TradeGoods9ComboBox";
            this._TradeGoods9ComboBox.Size = new System.Drawing.Size(160, 23);
            this._TradeGoods9ComboBox.TabIndex = 16;
            // 
            // _TradeGoods10ComboBox
            // 
            this._TradeGoods10ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._TradeGoods10ComboBox.FormattingEnabled = true;
            this._TradeGoods10ComboBox.Location = new System.Drawing.Point(73, 318);
            this._TradeGoods10ComboBox.Name = "_TradeGoods10ComboBox";
            this._TradeGoods10ComboBox.Size = new System.Drawing.Size(160, 23);
            this._TradeGoods10ComboBox.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 15);
            this.label1.TabIndex = 200;
            this.label1.Text = "交易品1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 15);
            this.label2.TabIndex = 200;
            this.label2.Text = "交易品2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 15);
            this.label3.TabIndex = 200;
            this.label3.Text = "交易品3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 15);
            this.label4.TabIndex = 200;
            this.label4.Text = "交易品4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 15);
            this.label5.TabIndex = 200;
            this.label5.Text = "交易品5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 185);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 15);
            this.label6.TabIndex = 200;
            this.label6.Text = "交易品6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 219);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 15);
            this.label7.TabIndex = 200;
            this.label7.Text = "交易品7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 253);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 15);
            this.label8.TabIndex = 200;
            this.label8.Text = "交易品8";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 287);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 15);
            this.label9.TabIndex = 200;
            this.label9.Text = "交易品9";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 321);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 15);
            this.label10.TabIndex = 200;
            this.label10.Text = "交易品10";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(248, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 15);
            this.label11.TabIndex = 200;
            this.label11.Text = "供給率";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(248, 49);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 15);
            this.label12.TabIndex = 200;
            this.label12.Text = "供給率";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(248, 83);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 15);
            this.label13.TabIndex = 200;
            this.label13.Text = "供給率";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(248, 117);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 15);
            this.label14.TabIndex = 200;
            this.label14.Text = "供給率";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(248, 151);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 15);
            this.label15.TabIndex = 200;
            this.label15.Text = "供給率";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(248, 185);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 15);
            this.label16.TabIndex = 200;
            this.label16.Text = "供給率";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(248, 219);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 15);
            this.label17.TabIndex = 200;
            this.label17.Text = "供給率";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(248, 253);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 15);
            this.label18.TabIndex = 200;
            this.label18.Text = "供給率";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(248, 287);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 15);
            this.label19.TabIndex = 200;
            this.label19.Text = "供給率";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(248, 321);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(43, 15);
            this.label20.TabIndex = 200;
            this.label20.Text = "供給率";
            // 
            // _TradeGoodsSupplyRate1TextBox
            // 
            this._TradeGoodsSupplyRate1TextBox.Location = new System.Drawing.Point(299, 12);
            this._TradeGoodsSupplyRate1TextBox.MaxLength = 3;
            this._TradeGoodsSupplyRate1TextBox.Name = "_TradeGoodsSupplyRate1TextBox";
            this._TradeGoodsSupplyRate1TextBox.Size = new System.Drawing.Size(113, 23);
            this._TradeGoodsSupplyRate1TextBox.TabIndex = 1;
            this._ToolTip.SetToolTip(this._TradeGoodsSupplyRate1TextBox, "0-255");
            // 
            // _TradeGoodsSupplyRate2TextBox
            // 
            this._TradeGoodsSupplyRate2TextBox.Location = new System.Drawing.Point(299, 46);
            this._TradeGoodsSupplyRate2TextBox.MaxLength = 3;
            this._TradeGoodsSupplyRate2TextBox.Name = "_TradeGoodsSupplyRate2TextBox";
            this._TradeGoodsSupplyRate2TextBox.Size = new System.Drawing.Size(113, 23);
            this._TradeGoodsSupplyRate2TextBox.TabIndex = 3;
            this._ToolTip.SetToolTip(this._TradeGoodsSupplyRate2TextBox, "0-255");
            // 
            // _TradeGoodsSupplyRate3TextBox
            // 
            this._TradeGoodsSupplyRate3TextBox.Location = new System.Drawing.Point(299, 80);
            this._TradeGoodsSupplyRate3TextBox.MaxLength = 3;
            this._TradeGoodsSupplyRate3TextBox.Name = "_TradeGoodsSupplyRate3TextBox";
            this._TradeGoodsSupplyRate3TextBox.Size = new System.Drawing.Size(113, 23);
            this._TradeGoodsSupplyRate3TextBox.TabIndex = 5;
            this._ToolTip.SetToolTip(this._TradeGoodsSupplyRate3TextBox, "0-255");
            // 
            // _TradeGoodsSupplyRate4TextBox
            // 
            this._TradeGoodsSupplyRate4TextBox.Location = new System.Drawing.Point(299, 114);
            this._TradeGoodsSupplyRate4TextBox.MaxLength = 3;
            this._TradeGoodsSupplyRate4TextBox.Name = "_TradeGoodsSupplyRate4TextBox";
            this._TradeGoodsSupplyRate4TextBox.Size = new System.Drawing.Size(113, 23);
            this._TradeGoodsSupplyRate4TextBox.TabIndex = 7;
            this._ToolTip.SetToolTip(this._TradeGoodsSupplyRate4TextBox, "0-255");
            // 
            // _TradeGoodsSupplyRate5TextBox
            // 
            this._TradeGoodsSupplyRate5TextBox.Location = new System.Drawing.Point(299, 148);
            this._TradeGoodsSupplyRate5TextBox.MaxLength = 3;
            this._TradeGoodsSupplyRate5TextBox.Name = "_TradeGoodsSupplyRate5TextBox";
            this._TradeGoodsSupplyRate5TextBox.Size = new System.Drawing.Size(113, 23);
            this._TradeGoodsSupplyRate5TextBox.TabIndex = 9;
            this._ToolTip.SetToolTip(this._TradeGoodsSupplyRate5TextBox, "0-255");
            // 
            // _TradeGoodsSupplyRate6TextBox
            // 
            this._TradeGoodsSupplyRate6TextBox.Location = new System.Drawing.Point(299, 182);
            this._TradeGoodsSupplyRate6TextBox.MaxLength = 3;
            this._TradeGoodsSupplyRate6TextBox.Name = "_TradeGoodsSupplyRate6TextBox";
            this._TradeGoodsSupplyRate6TextBox.Size = new System.Drawing.Size(113, 23);
            this._TradeGoodsSupplyRate6TextBox.TabIndex = 11;
            this._ToolTip.SetToolTip(this._TradeGoodsSupplyRate6TextBox, "0-255");
            // 
            // _TradeGoodsSupplyRate7TextBox
            // 
            this._TradeGoodsSupplyRate7TextBox.Location = new System.Drawing.Point(299, 216);
            this._TradeGoodsSupplyRate7TextBox.MaxLength = 3;
            this._TradeGoodsSupplyRate7TextBox.Name = "_TradeGoodsSupplyRate7TextBox";
            this._TradeGoodsSupplyRate7TextBox.Size = new System.Drawing.Size(113, 23);
            this._TradeGoodsSupplyRate7TextBox.TabIndex = 13;
            this._ToolTip.SetToolTip(this._TradeGoodsSupplyRate7TextBox, "0-255");
            // 
            // _TradeGoodsSupplyRate8TextBox
            // 
            this._TradeGoodsSupplyRate8TextBox.Location = new System.Drawing.Point(299, 250);
            this._TradeGoodsSupplyRate8TextBox.MaxLength = 3;
            this._TradeGoodsSupplyRate8TextBox.Name = "_TradeGoodsSupplyRate8TextBox";
            this._TradeGoodsSupplyRate8TextBox.Size = new System.Drawing.Size(113, 23);
            this._TradeGoodsSupplyRate8TextBox.TabIndex = 15;
            this._ToolTip.SetToolTip(this._TradeGoodsSupplyRate8TextBox, "0-255");
            // 
            // _TradeGoodsSupplyRate9TextBox
            // 
            this._TradeGoodsSupplyRate9TextBox.Location = new System.Drawing.Point(299, 284);
            this._TradeGoodsSupplyRate9TextBox.MaxLength = 3;
            this._TradeGoodsSupplyRate9TextBox.Name = "_TradeGoodsSupplyRate9TextBox";
            this._TradeGoodsSupplyRate9TextBox.Size = new System.Drawing.Size(113, 23);
            this._TradeGoodsSupplyRate9TextBox.TabIndex = 17;
            this._ToolTip.SetToolTip(this._TradeGoodsSupplyRate9TextBox, "0-255");
            // 
            // _TradeGoodsSupplyRate10TextBox
            // 
            this._TradeGoodsSupplyRate10TextBox.Location = new System.Drawing.Point(299, 318);
            this._TradeGoodsSupplyRate10TextBox.MaxLength = 3;
            this._TradeGoodsSupplyRate10TextBox.Name = "_TradeGoodsSupplyRate10TextBox";
            this._TradeGoodsSupplyRate10TextBox.Size = new System.Drawing.Size(113, 23);
            this._TradeGoodsSupplyRate10TextBox.TabIndex = 19;
            this._ToolTip.SetToolTip(this._TradeGoodsSupplyRate10TextBox, "0-255");
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 370);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(221, 15);
            this.label21.TabIndex = 200;
            this.label21.Text = "※ 月の供給量 = (15+規模)x(1+供給率/4)";
            // 
            // _ToolTip
            // 
            this._ToolTip.AutoPopDelay = 5000;
            this._ToolTip.InitialDelay = 100;
            this._ToolTip.ReshowDelay = 100;
            // 
            // TradeGoodsEditForm
            // 
            this.AcceptButton = this._OKButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.CancelButton = this._CancelButton;
            this.ClientSize = new System.Drawing.Size(424, 401);
            this.Controls.Add(this.label21);
            this.Controls.Add(this._TradeGoodsSupplyRate10TextBox);
            this.Controls.Add(this._TradeGoodsSupplyRate9TextBox);
            this.Controls.Add(this._TradeGoodsSupplyRate8TextBox);
            this.Controls.Add(this._TradeGoodsSupplyRate7TextBox);
            this.Controls.Add(this._TradeGoodsSupplyRate6TextBox);
            this.Controls.Add(this._TradeGoodsSupplyRate5TextBox);
            this.Controls.Add(this._TradeGoodsSupplyRate4TextBox);
            this.Controls.Add(this._TradeGoodsSupplyRate3TextBox);
            this.Controls.Add(this._TradeGoodsSupplyRate2TextBox);
            this.Controls.Add(this._TradeGoodsSupplyRate1TextBox);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this._TradeGoods10ComboBox);
            this.Controls.Add(this._TradeGoods9ComboBox);
            this.Controls.Add(this._TradeGoods8ComboBox);
            this.Controls.Add(this._TradeGoods7ComboBox);
            this.Controls.Add(this._TradeGoods6ComboBox);
            this.Controls.Add(this._TradeGoods5ComboBox);
            this.Controls.Add(this._TradeGoods4ComboBox);
            this.Controls.Add(this._TradeGoods3ComboBox);
            this.Controls.Add(this._TradeGoods2ComboBox);
            this.Controls.Add(this._TradeGoods1ComboBox);
            this.Controls.Add(this._CancelButton);
            this.Controls.Add(this._OKButton);
            this.Name = "TradeGoodsEditForm";
            this.Text = "町：交易品の編集";
            this.Load += new System.EventHandler(this.TradeGoodsEditForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button _CancelButton;
        private System.Windows.Forms.Button _OKButton;
        private System.Windows.Forms.ComboBox _TradeGoods1ComboBox;
        private System.Windows.Forms.ComboBox _TradeGoods2ComboBox;
        private System.Windows.Forms.ComboBox _TradeGoods3ComboBox;
        private System.Windows.Forms.ComboBox _TradeGoods4ComboBox;
        private System.Windows.Forms.ComboBox _TradeGoods5ComboBox;
        private System.Windows.Forms.ComboBox _TradeGoods6ComboBox;
        private System.Windows.Forms.ComboBox _TradeGoods7ComboBox;
        private System.Windows.Forms.ComboBox _TradeGoods8ComboBox;
        private System.Windows.Forms.ComboBox _TradeGoods9ComboBox;
        private System.Windows.Forms.ComboBox _TradeGoods10ComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox _TradeGoodsSupplyRate1TextBox;
        private System.Windows.Forms.TextBox _TradeGoodsSupplyRate2TextBox;
        private System.Windows.Forms.TextBox _TradeGoodsSupplyRate3TextBox;
        private System.Windows.Forms.TextBox _TradeGoodsSupplyRate4TextBox;
        private System.Windows.Forms.TextBox _TradeGoodsSupplyRate5TextBox;
        private System.Windows.Forms.TextBox _TradeGoodsSupplyRate6TextBox;
        private System.Windows.Forms.TextBox _TradeGoodsSupplyRate7TextBox;
        private System.Windows.Forms.TextBox _TradeGoodsSupplyRate8TextBox;
        private System.Windows.Forms.TextBox _TradeGoodsSupplyRate9TextBox;
        private System.Windows.Forms.TextBox _TradeGoodsSupplyRate10TextBox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ToolTip _ToolTip;
    }
}